import torch as th
from torch import nn
from torch.nn import init
import dgl.function as fn
from dgl._ffi.base import DGLError
from dgl.convert import block_to_graph
from dgl.heterograph import DGLBlock
from dgl.transforms import reverse
from dgl.utils import expand_as_pair

class GraphConv(nn.Module):

    def __init__(
        self,
        in_feats,
        out_feats,
        norm="both",
        weight=True,
        bias=True,
        activation=None,
        allow_zero_in_degree=False,
    ):
        super(GraphConv, self).__init__()
        if norm not in ("none", "both", "right", "left"):
            raise DGLError(
                'Invalid norm value. Must be either "none", "both", "right" or "left".'
                ' But got "{}".'.format(norm)
            )
        self._in_feats = in_feats
        self._out_feats = out_feats
        self._norm = norm
        self._allow_zero_in_degree = allow_zero_in_degree

        if weight:
            self.weight = nn.Parameter(th.Tensor(in_feats, out_feats))
        else:
            self.register_parameter("weight", None)

        if bias:
            self.bias = nn.Parameter(th.Tensor(out_feats))
        else:
            self.register_parameter("bias", None)

        self.reset_parameters()

        self._activation = activation

    def reset_parameters(self):
        if self.weight is not None:
            init.xavier_uniform_(self.weight)
        if self.bias is not None:
            init.zeros_(self.bias)

    def set_allow_zero_in_degree(self, set_value):
        self._allow_zero_in_degree = set_value

    def forward(self, graph, feat, sim, adj,  weight=None, edge_weight=None):


        stype = graph.srctypes[0]           # stype 源节点 str
        dtype = graph.dsttypes[0]           # dtype 目标节点 str


        with graph.local_scope():

            if not self._allow_zero_in_degree:

                if (graph.in_degrees() == 0).any():
                    raise DGLError(
                        "There are 0-in-degree nodes in the graph, "
                        "output for those nodes will be invalid. "
                        "This is harmful for some applications, "
                        "causing silent performance regression. "
                        "Adding self-loop on the input graph by "
                        "calling `g = dgl.add_self_loop(g)` will resolve "
                        "the issue. Setting ``allow_zero_in_degree`` "
                        "to be `True` when constructing this module will "
                        "suppress the check and let the code run."
                    )

            weight = self.weight

            x = th.sum(adj,1)
            D = th.diag(x)
            D = th.pow(D,-0.5)
            D = th.where(th.isinf(D), th.full_like(D, 0), D)



            A = adj

            diag = th.diag(sim)
            a_diag = th.diag_embed(diag)
            sim = sim - a_diag

            if stype == dtype:
                feat = feat[0]
                part1 = th.mm(th.mm(D,A),D)
                part2 = part1 + 0.4*sim
                part3  =th.mm(part2,feat)
                feature =th.mm(part3,weight)

                if self.bias is not None:
                    feature = feature + self.bias

                if self._activation is not None:
                    feature = self._activation(feature)

                rst = {dtype:feature}
                return rst

            else:
                feat_src = feat[0]
                feat_dst = feat[1]

                len_src = len(feat_src)
                len_dst = len(feat_dst)

                feat = th.vstack((feat_src,feat_dst))
                part1 = th.mm(th.mm(D,A),D)
                part2 = part1 + 0.4* sim
                #part2 = part1
                part3  =th.mm(part2,feat)
                feature =th.mm(part3,weight)

                if self.bias is not None:
                    feature = feature + self.bias

                if self._activation is not None:
                    feature = self._activation(feature)

                feature_src = feature[0:len_src,:]
                feature_dst = feature[len_src:,:]

                rst = {stype:feature_src, dtype:feature_dst}
                return rst




