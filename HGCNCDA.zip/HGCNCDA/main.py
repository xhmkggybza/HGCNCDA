import os
import numpy as np
import pandas as pd
import torch as th
from warnings import simplefilter
from model import Model
from sklearn.model_selection import KFold
from args import args
from utils import get_metrics_auc, set_seed, plot_result_auc,\
    plot_result_aupr, EarlyStopping, get_metrics
from load_data import load, remove_graph
from sklearn.metrics import roc_curve, roc_auc_score, \
    precision_recall_curve, average_precision_score


print(args)

try:
    os.mkdir(args.saved_path)
except:
    pass

print('Training on GPU')
device = th.device('cuda')


df = pd.read_excel('{}.xlsx'.format(args.dataset), header=None).values


dd = pd.read_excel('./GaussianSim/ddGaussian.xlsx',header=None).values
ll = pd.read_excel('./GaussianSim/llGaussian.xlsx',header=None).values
mm = pd.read_excel('./GaussianSim/mmGaussian.xlsx',header=None).values
cm = pd.read_excel('./GaussianSim/cmGaussian.xlsx',header=None).values
ld = pd.read_excel('./GaussianSim/ldGaussian.xlsx',header=None).values
lm = pd.read_excel('./GaussianSim/lmGaussian.xlsx',header=None).values
md = pd.read_excel('./GaussianSim/mdGaussian.xlsx',header=None).values

dd = th.from_numpy(dd).to(th.float32).to(device)
ll = th.from_numpy(ll).to(th.float32).to(device)
mm = th.from_numpy(mm).to(th.float32).to(device)
cm = th.from_numpy(cm).to(th.float32).to(device)
ld = th.from_numpy(ld).to(th.float32).to(device)
lm = th.from_numpy(lm).to(th.float32).to(device)
md = th.from_numpy(md).to(th.float32).to(device)


adjdd = pd.read_excel('./ADjM/disease-disease.xlsx',header=None).values
adjll = pd.read_excel('./ADjM/lncRNA-lncRNA.xlsx',header=None).values
adjmm = pd.read_excel('./ADjM/miRNA-miRNA.xlsx',header=None).values
adjcm = pd.read_excel('./ADjM/CMT.xlsx',header=None).values
adjld = pd.read_excel('./ADjM/LDT.xlsx',header=None).values
adjlm = pd.read_excel('./ADjM/LMT.xlsx',header=None).values
adjmd = pd.read_excel('./ADjM/MDT.xlsx',header=None).values

adjdd = th.from_numpy(adjdd).to(th.float32).to(device)
adjll = th.from_numpy(adjll).to(th.float32).to(device)
adjmm = th.from_numpy(adjmm).to(th.float32).to(device)
adjcm = th.from_numpy(adjcm).to(th.float32).to(device)
adjld = th.from_numpy(adjld).to(th.float32).to(device)
adjlm = th.from_numpy(adjlm).to(th.float32).to(device)
adjmd = th.from_numpy(adjmd).to(th.float32).to(device)


data = np.array([[i, j, df[i, j]] for i in range(df.shape[0]) for j in range(df.shape[1])])
data = data.astype('int64')   # 101016*3


set_seed(args.seed)

pred_result = np.zeros(df.shape)

aucs = []
auprs = []
accs = []
pres = []
f1s = []
recs = []
specs = []

for fold in range(1,6):

    print('{}-Cross Validation: Fold {}'.format(args.nfold, fold))
    i = fold
    i = str(i)

    train_id = pd.read_excel('5Fold/'+i+'train_id_5Fold.xlsx',header=None).values
    test_id = pd.read_excel('5Fold/'+i+'test_id_5Fold.xlsx',header=None).values

    train_pos_id = train_id[np.where(train_id[:, -1] == 1)[0]]
    train_neg_id = train_id[np.where(train_id[:, -1] == 0)[0]]

    test_pos_id = test_id[np.where(test_id[:, -1] == 1)[0]]
    test_neg_id = test_id[np.where(test_id[:, -1] == 0)[0]]

    train_id = train_id[:, :2]
    test_id = test_id[:, :2]

    g = load(fold)
    g = g.to(device)

    feature = {'circRNA': g.nodes['circRNA'].data['h'], 'disease': g.nodes['disease'].data['h'],
               'miRNA': g.nodes['miRNA'].data['h'], 'lncRNA': g.nodes['lncRNA'].data['h']}



    cc = pd.read_excel('./GaussianSim/ccGaussian'+i+'.xlsx', header=None).values
    cd = pd.read_excel('./GaussianSim/cdGaussian'+i+'.xlsx', header=None).values

    cc = th.from_numpy(cc).to(th.float32).to(device)

    cd = th.from_numpy(cd).to(th.float32).to(device)


    sim = {'circRNA_circRNA':cc, 'disease_disease':dd, 'lncRNA_lncRNA':ll, 'miRNA_miRNA':mm,
           'circRNA_disease':cd, 'circRNA_miRNA':cm, 'lncRNA_disease':ld, 'lncRNA_miRNA':lm,
           'miRNA_disease':md}

    adjcc = pd.read_excel('./ADjM/circRNA-circRNA'+i+'.xlsx', header=None).values
    adjcd = pd.read_excel('./ADjM/CDT'+i+'.xlsx', header=None).values

    adjcc = th.from_numpy(adjcc).to(th.float32).to(device)

    adjcd = th.from_numpy(adjcd).to(th.float32).to(device)


    adj = {'circRNA_circRNA':adjcc, 'disease_disease':adjdd, 'lncRNA_lncRNA':adjll, 'miRNA_miRNA':adjmm,
           'circRNA_disease':adjcd, 'circRNA_miRNA':adjcm, 'lncRNA_disease':adjld, 'lncRNA_miRNA':adjlm,
           'miRNA_disease':adjmd}


    label = th.tensor(df).float().to(device)

    model = Model(etypes=g.etypes, ntypes=g.ntypes,
                  in_feats=feature['circRNA'].shape[1],
                  hidden_feats=args.hidden_feats,
                  num_heads=args.num_heads,
                  dropout=args.dropout)

    model.to(device)


    optimizer = th.optim.Adam(model.parameters(),
                              lr=args.learning_rate,
                              weight_decay=args.weight_decay)


    optim_scheduler = th.optim.lr_scheduler.CyclicLR(optimizer,
                                                     base_lr=0.1 * args.learning_rate,
                                                     max_lr=args.learning_rate,
                                                     gamma=0.995,
                                                     step_size_up=20,
                                                     mode="exp_range",
                                                     cycle_momentum=False)

    criterion = th.nn.BCEWithLogitsLoss(pos_weight=th.tensor(0.3*(len(train_neg_id) / len(train_pos_id))))
    print('Loss pos weight: {:.3f}'.format(len(train_neg_id) / len(train_pos_id)))

    stopper = EarlyStopping(patience=args.patience, saved_path=args.saved_path)

    for epoch in range(1, args.epoch + 1):

        model.train()
        score = model(g, feature, sim, adj)
        pred = th.sigmoid(score)

        loss = criterion(score[train_id[:,0],train_id[:,1]].cpu().flatten(),
                         label[train_id[:,0],train_id[:,1]].cpu().flatten())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        optim_scheduler.step()

        model.eval()

        AUC_, _ = get_metrics_auc(label[train_id[:,0],train_id[:,1]].cpu().detach().numpy(),
                                  pred[train_id[:,0],train_id[:,1]].cpu().detach().numpy())
        early_stop = stopper.step(loss.item(), AUC_, model)

        score = model(g, feature, sim, adj)
        pred = th.sigmoid(score)

        if epoch % 20 == 0:
            AUC, AUPR = get_metrics_auc(label[test_id[:,0],test_id[:,1]].cpu().detach().numpy(),
                                        pred[test_id[:,0],test_id[:,1]].cpu().detach().numpy())
            print('Epoch {} Loss: {:.3f}; Train AUC {:.3f}; AUC {:.3f}; AUPR: {:.3f}'.format(epoch, loss.item(),
                                                                                             AUC_, AUC, AUPR))
            print('-' * 50)
            if early_stop:
                break

    stopper.load_checkpoint(model)
    model.eval()
    pred = th.sigmoid(model(g, feature, sim, adj)).cpu().detach().numpy()
    AUC, AUPR = get_metrics_auc(label[test_id[:,0],test_id[:,1]].cpu().detach().numpy(),
                                pred[test_id[:,0],test_id[:,1]])
    _, _, acc, f1, pre, rec, spec = get_metrics(label[test_id[:,0],test_id[:,1]].cpu().detach().numpy(),
                                                     pred[test_id[:,0],test_id[:,1]])


    aucs.append(AUC)
    auprs.append(AUPR)
    accs.append(acc)
    f1s.append(f1)
    pres.append(pre)
    recs.append(rec)
    specs.append(spec)




    pred_result[test_pos_id[:, 0], test_pos_id[:, 1]] = pred[test_pos_id[:, 0], test_pos_id[:, 1]]

    pred_result[test_neg_id[:, 0], test_neg_id[:, 1]] = pred[test_neg_id[:, 0], test_neg_id[:, 1]]

aucs = np.array(aucs)
auprs = np.array(auprs)
accs = np.array(accs)
f1s = np.array(f1s)
pres = np.array(pres)
recs = np.array(recs)
specs = np.array(specs)
print('aucs',aucs)
print('auprs',auprs)
print('accs',accs)
print('f1s',f1s)
print('pres',pres)
print('recs',recs)
print('specs',specs)
print('五折交叉验证平均值')
print('AUC:',np.mean(aucs))
print('AUPR',np.mean(auprs))
print('ACC:',np.mean(accs))
print('F1',np.mean(f1s))
print('Pre:',np.mean(pres))
print('Rec',np.mean(recs))
print('Spec:',np.mean(specs))

AUC, aupr, acc, f1, pre, rec, spec = get_metrics(label.cpu().detach().numpy().flatten(), pred_result.flatten())
print(
    'Overall: AUC {:.3f}; AUPR: {:.3f}; Acc: {:.3f}; F1: {:.3f}; Precision {:.3f}; Recall {:.3f}'.
        format(AUC, aupr, acc, f1, pre, rec))
pd.DataFrame(pred_result).to_csv(os.path.join(args.saved_path,
                                                'result.csv'), index=False, header=False)

fpr, tpr, threshold = roc_curve(data[:, -1].flatten(), pred_result.flatten())
fpr = pd.DataFrame(fpr)
tpr = pd.DataFrame(tpr)

writer = pd.ExcelWriter('figure/HGCN_fpr.xlsx')
fpr.to_excel(writer, 'page_1',header=None,index=None)
writer._save()

writer = pd.ExcelWriter('figure/HGCN_tpr.xlsx')
tpr.to_excel(writer, 'page_1',header=None,index=None)
writer._save()

