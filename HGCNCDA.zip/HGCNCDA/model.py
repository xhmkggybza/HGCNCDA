import torch
import torch.nn as nn
import dgl.nn.pytorch as dglnn
import dgl
import Highorder_GCN
import HeteroGCN

class InnerProductDecoder(nn.Module):
    """Decoder model layer for link prediction."""

    def __init__(self, input_dim=None, dropout=0.4):
        super(InnerProductDecoder, self).__init__()
        self.dropout = nn.Dropout(dropout)
        if input_dim:
            self.weights = nn.Linear(input_dim, input_dim, bias=False)
            nn.init.xavier_uniform_(self.weights.weight)

    def forward(self, feature):
        feature['circRNA'] = self.dropout(feature['circRNA'])
        feature['disease'] = self.dropout(feature['disease'])
        R = feature['circRNA']
        D = feature['disease']
        D = self.weights(D)
        outputs = R @ D.T
        return outputs


class Node_Embedding(nn.Module):
    """The base HeteroGCN layer."""

    def __init__(self, in_feats, out_feats, dropout, rel_names):
        super().__init__()
        HeteroGraphdict = {}
        for rel in rel_names:

            HGCN = Highorder_GCN.GraphConv(in_feats, out_feats)
            nn.init.xavier_normal_(HGCN.weight)
            HeteroGraphdict[rel] = HGCN
        self.dropout = nn.Dropout(p=dropout)

        self.embedding = HeteroGCN.HeteroGraphConv(HeteroGraphdict, aggregate='mean')

        self.bn_layer = nn.BatchNorm1d(out_feats)
        self.prelu = nn.ELU()

    def forward(self, graph, inputs, sim, adj, bn=False, dp=False):

        h = self.embedding(graph, inputs,sim,adj)
        if bn and dp:
            h = {k: self.prelu(self.dropout(self.bn_layer(v))) for k, v in h.items()}
        elif dp:
            h = {k: self.prelu(self.dropout(v)) for k, v in h.items()}
        elif bn:
            h = {k: self.prelu(self.bn_layer(v)) for k, v in h.items()}
        else:
            h = {k: self.prelu(v) for k, v in h.items()}
        return h

class SemanticAttention(nn.Module):
    """The base attention mechanism used in
    topological subnet embedding block and layer attention block.
    """

    def __init__(self, in_feats, hidden_size=128):
        super(SemanticAttention, self).__init__()

        self.project = nn.Sequential(
            nn.Linear(in_feats, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z, is_print=False):
        w = self.project(z).mean(0)
        beta = torch.softmax(w, dim=0)
        beta = beta.expand((z.shape[0],) + beta.shape)
        if is_print:
            print(beta)
        return (beta * z).sum(1)

class SubnetworkEncoder(nn.Module):
    """Topological subnet embedding block."""

    def __init__(self, in_feats, out_feats, dropout):
        super(SubnetworkEncoder, self).__init__()
        self.circRNA_disease = Node_Embedding(in_feats, out_feats, dropout,
                                           ['circRNA_circRNA', 'circRNA_disease', 'disease_disease'])
        self.circRNA_miRNA = Node_Embedding(in_feats, out_feats, dropout,
                                           ['circRNA_circRNA', 'circRNA_miRNA', 'miRNA_miRNA'])
        self.lncRNA_disease = Node_Embedding(in_feats, out_feats, dropout,
                                           ['lncRNA_lncRNA', 'lncRNA_disease', 'disease_disease'])
        self.lncRNA_miRNA = Node_Embedding(in_feats, out_feats, dropout,
                                           ['lncRNA_lncRNA', 'lncRNA_miRNA', 'miRNA_miRNA'])
        self.miRNA_disease = Node_Embedding(in_feats, out_feats, dropout,
                                              ['miRNA_miRNA', 'miRNA_disease', 'disease_disease'])
        self.semantic_attention = SemanticAttention(in_feats=out_feats)

    def forward(self, g, h,sim, adj, bn=False, dp=False):
        new_h = {'circRNA': [], 'disease': [], 'lncRNA': [], 'miRNA': []}
        # circRNA-disease subnet
        g_ = g.edge_type_subgraph(['circRNA_circRNA', 'circRNA_disease', 'disease_disease'])
        h_ = self.circRNA_disease(g_, {'circRNA': h['circRNA'], 'disease': h['disease']},sim, adj, bn, dp)
        new_h['circRNA'].append(h_['circRNA'])
        new_h['disease'].append(h_['disease'])
        # circRNA-miRNA subnet
        g_ = g.edge_type_subgraph(['circRNA_circRNA', 'circRNA_miRNA', 'miRNA_miRNA'])
        h_ = self.circRNA_miRNA(g_, {'circRNA': h['circRNA'], 'miRNA': h['miRNA']},sim, adj, bn, dp)
        new_h['circRNA'].append(h_['circRNA'])
        new_h['miRNA'].append(h_['miRNA'])
        # lncRNA-disease subnet
        g_ = g.edge_type_subgraph(['lncRNA_lncRNA', 'lncRNA_disease', 'disease_disease'])
        h_ = self.lncRNA_disease(g_, {'lncRNA': h['lncRNA'], 'disease': h['disease']},sim, adj, bn, dp)
        new_h['lncRNA'].append(h_['lncRNA'])
        new_h['disease'].append(h_['disease'])
        # lncRNA-miRNA subnet
        g_ = g.edge_type_subgraph(['lncRNA_lncRNA', 'lncRNA_miRNA', 'miRNA_miRNA'])
        h_ = self.lncRNA_miRNA(g_, {'lncRNA': h['lncRNA'], 'miRNA': h['miRNA']},sim, adj, bn, dp)
        new_h['lncRNA'].append(h_['lncRNA'])
        new_h['miRNA'].append(h_['miRNA'])
        # miRNA-disease subnet
        g_ = g.edge_type_subgraph(['miRNA_miRNA', 'miRNA_disease', 'disease_disease'])
        h_ = self.miRNA_disease(g_, {'miRNA': h['miRNA'], 'disease': h['disease']},sim, adj, bn, dp)
        new_h['miRNA'].append(h_['miRNA'])
        new_h['disease'].append(h_['disease'])
        # aggragation with attention mechanism
        h['circRNA'] = self.semantic_attention(torch.stack(new_h['circRNA'], dim=1))
        h['disease'] = self.semantic_attention(torch.stack(new_h['disease'], dim=1))
        h['lncRNA'] = self.semantic_attention(torch.stack(new_h['lncRNA'], dim=1))
        h['miRNA'] = self.semantic_attention(torch.stack(new_h['miRNA'], dim=1))

        return h

class Graph_attention(nn.Module):
    """Multi-omics graph attention block."""

    def __init__(self, in_feats, out_feats, num_heads, dropout):
        super().__init__()
        self.gat = dglnn.GATConv(in_feats, out_feats, num_heads,
                                 dropout, dropout,
                                 activation=nn.PReLU(),
                                 allow_zero_in_degree=True)
        self.gat.reset_parameters()
        self.linear = nn.Linear(in_feats * num_heads, out_feats)
        self.prelu = nn.PReLU()
        self.bn_layer = nn.BatchNorm1d(out_feats)

    def forward(self, graph, inputs, bn=False):
        # disease drug gene pathway protein
        num_dis = graph.num_nodes('disease')
        num_circRNA = graph.num_nodes('circRNA')
        new_g = dgl.to_homogeneous(graph)
        new_h = torch.cat([i for i in inputs.values()], dim=0)
        new_h = self.gat(new_g, new_h)
        new_h = self.prelu(torch.mean(new_h, dim=1))
        if bn:
            return self.bn_layer(new_h[:num_circRNA]), self.bn_layer(new_h[num_circRNA:num_circRNA + num_dis])
        return new_h[:num_circRNA], new_h[num_circRNA:num_circRNA + num_dis]

class Model(nn.Module):
    """The overall MODDA architecture."""

    def __init__(self, etypes, ntypes, in_feats, hidden_feats, num_heads, dropout):

        super(Model, self).__init__()


        self.circRNA_linear = nn.Linear(in_feats, hidden_feats)
        nn.init.xavier_normal_(self.circRNA_linear.weight)
        self.disease_linear = nn.Linear(in_feats, hidden_feats)
        nn.init.xavier_normal_(self.disease_linear.weight)
        self.lncRNA_linear = nn.Linear(in_feats, hidden_feats)
        nn.init.xavier_normal_(self.lncRNA_linear.weight)
        self.miRNA_linear = nn.Linear(in_feats, hidden_feats)
        nn.init.xavier_normal_(self.miRNA_linear.weight)


        self.feat_generate_layer1 = Node_Embedding(hidden_feats, hidden_feats, dropout, etypes)
        self.feat_generate_layer2 = Node_Embedding(hidden_feats, hidden_feats, dropout, etypes)
        self.feat_generate_layer3 = Node_Embedding(hidden_feats, hidden_feats, dropout, etypes)


        self.subnet_layer = SubnetworkEncoder(hidden_feats, hidden_feats, dropout)

        self.totalnet_layer = Graph_attention(hidden_feats, hidden_feats, num_heads, dropout)

        self.layer_attention_layer_circRNA = SemanticAttention(hidden_feats)
        self.layer_attention_layer_dis = SemanticAttention(hidden_feats)


        self.circRNA_linearR = nn.Linear(hidden_feats, 828)
        nn.init.xavier_normal_(self.circRNA_linearR.weight)
        self.disease_linearR = nn.Linear(hidden_feats, 122)
        nn.init.xavier_normal_(self.disease_linearR.weight)

        self.predict = InnerProductDecoder(hidden_feats)

    def forward(self, g, x, sim, adj):

        circRNA_emb_list, dis_emb_list = [], []
        h = {'circRNA': x['circRNA'], 'disease': x['disease'],
             'lncRNA': x['lncRNA'], 'miRNA': x['miRNA']}

        h['circRNA'] = self.circRNA_linear(h['circRNA'])
        h['disease'] = self.disease_linear(h['disease'])
        h['lncRNA'] = self.lncRNA_linear(h['lncRNA'])
        h['miRNA'] = self.miRNA_linear(h['miRNA'])
        circRNA_emb_list.append(h['circRNA'])
        dis_emb_list.append(h['disease'])

        sim = {'circRNA_circRNA': sim['circRNA_circRNA'], 'disease_disease': sim['disease_disease'],
               'lncRNA_lncRNA': sim['lncRNA_lncRNA'], 'miRNA_miRNA': sim['miRNA_miRNA'],
               'circRNA_disease': sim['circRNA_disease'], 'circRNA_miRNA': sim['circRNA_miRNA'],
               'lncRNA_disease': sim['lncRNA_disease'], 'lncRNA_miRNA': sim['lncRNA_miRNA'],
               'miRNA_disease': sim['miRNA_disease']}

        adj = {'circRNA_circRNA': adj['circRNA_circRNA'], 'disease_disease': adj['disease_disease'],
               'lncRNA_lncRNA': adj['lncRNA_lncRNA'], 'miRNA_miRNA': adj['miRNA_miRNA'],
               'circRNA_disease': adj['circRNA_disease'], 'circRNA_miRNA': adj['circRNA_miRNA'],
               'lncRNA_disease': adj['lncRNA_disease'], 'lncRNA_miRNA': adj['lncRNA_miRNA'],
               'miRNA_disease': adj['miRNA_disease']}

        h = self.feat_generate_layer1(g, h, sim, adj, bn=True, dp=True)

        circRNA_emb_list.append(h['circRNA'])
        dis_emb_list.append(h['disease'])

        h = self.subnet_layer(g, h, sim, adj, bn=False, dp=True)
        circRNA_emb_list.append(h['circRNA'])
        dis_emb_list.append(h['disease'])

        h['circRNA'] = self.layer_attention_layer_circRNA(torch.stack(circRNA_emb_list, dim=1))
        h['disease'] = self.layer_attention_layer_dis(torch.stack(dis_emb_list, dim=1))


        return self.predict(h)
